#!/bin/bash
echo "Removing old files..."
rm -rf /usr/share/nginx/html/*
