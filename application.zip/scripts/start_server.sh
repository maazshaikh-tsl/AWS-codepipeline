#!/bin/bash
echo "Restarting Nginx..."
systemctl restart nginx
